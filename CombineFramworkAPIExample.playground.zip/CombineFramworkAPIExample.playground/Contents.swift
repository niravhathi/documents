import UIKit
import PlaygroundSupport
import Combine
///*
struct API {
    
    /// API Errors
    /// List all errors that can be retrieved by URLSession
    enum Error: LocalizedError {
        case addressUnreachable(URL)
        case invalidResponse
        
        var errorDescription: String? {
            switch self {
            case .invalidResponse:
                return "Invalid response from the server"
            case .addressUnreachable(let url):
                return "Unreachable URL: \(url.absoluteString)"
            }
        }
    }
    
    /// API Endpoints
    /// Define all endpoints for the API
    enum EndPoint {
        static let baseURL = URL(string: "https://api.chucknorris.io/jokes/")!
        
        case random
        case category(String)
        case categories
        case query(String)
        
        var url: URL {
            switch self {
            case .random:
                return EndPoint.baseURL.appendingPathComponent("random")
            case .category(let category):
                var baseQueryURL = URLComponents(url: EndPoint.baseURL.appendingPathComponent("random"), resolvingAgainstBaseURL: false)!
                baseQueryURL.queryItems = [
                    URLQueryItem(name: "category", value: category)
                ]
                return baseQueryURL.url!
            case .categories:
                return EndPoint.baseURL.appendingPathComponent("categories")
            case .query(let query):
                var baseQueryURL = URLComponents(url: EndPoint.baseURL.appendingPathComponent("search"), resolvingAgainstBaseURL: false)!
                baseQueryURL.queryItems = [
                    URLQueryItem(name: "query", value: query)
                ]
                return baseQueryURL.url!
            }
        }
    }
    
    /// Private decoder for JSON decoding
    private let decoder = JSONDecoder()
    
    /// Specify the scheduler that manages the responses
    private let apiQueue = DispatchQueue(label: "ChuckNorrisAPI",
                                         qos: .default,
                                         attributes: .concurrent)
    
    //MARK: - API Methods
    
    /// Retrieve the publisher for a random quote
    func randomQuote() -> AnyPublisher<ChuckQuote, Error> {
        URLSession.shared
            .dataTaskPublisher(for: EndPoint.random.url)
            .receive(on: apiQueue)
            .map(\.data)
            .decode(type: ChuckQuote.self, decoder: decoder)
            .catch { _ in Empty<ChuckQuote, Error>() }
            .eraseToAnyPublisher()
    }
    
    func randomQuoteFrom(_ category: String) -> AnyPublisher<ChuckQuote, Error> {
        print(EndPoint.category(category).url)
        return URLSession.shared
            .dataTaskPublisher(for: EndPoint.category(category).url)
            .map(\.data)
            .decode(type: ChuckQuote.self, decoder: decoder)
            .mapError { (error) -> Error in
                switch error {
                case is URLError:
                    return Error.addressUnreachable(EndPoint.category(category).url)
                default:
                    return Error.invalidResponse
                }
        }
        .eraseToAnyPublisher()
    }

}

//MARK: - API Testing
let api = API()
var subscriptions = [AnyCancellable]()

api.randomQuote()
    .sink(receiveCompletion: { print($0) }, receiveValue: { print($0) })
    .store(in: &subscriptions)

api.randomQuoteFrom("animal")
    .sink(receiveCompletion: { print($0) }, receiveValue: { print($0) })
    .store(in: &subscriptions)

// Simulating error response
api.randomQuoteFrom("notExistingCategory")
    .sink(receiveCompletion: { print($0) }, receiveValue: { print($0) })
    .store(in: &subscriptions)

subscriptions[0].cancel()

//*/

 let publisher = [1, 2, 3, 4, 5].publisher

 // Subscribe to the publisher using the sink operator
 var cancellable: AnyCancellable?
 cancellable = publisher.sink(
    receiveCompletion: { completion in
        switch completion {
        case .finished:
            print("Publisher completed successfully.")
        case .failure(let error):
            print("Error: \(error)")
        }
    }, receiveValue: { value in
        print("Received value: \(value)")
    }
 )
 // This keeps the subscription alive
 // To release and cancel the subscription, set cancellable to nil
 cancellable = nil
 

let publisher1 = PassthroughSubject<Int, Never>()
let publisher2 = PassthroughSubject<Int, Never>()

let mergedPublisher = publisher1.merge(with: publisher2)
    .sink { value in
        print("Received value: \(value)")
    }

publisher1.send(1) // Output: Received value: 1
publisher2.send(2) // Output: Received value: 2
publisher1.send(3) // Output: Received value: 3


let temperaturePublisher = PassthroughSubject<Int, Never>()
let humidityPublisher = PassthroughSubject<Int, Never>()

let weatherPublisher = Publishers.CombineLatest(temperaturePublisher, humidityPublisher)
    .sink { temperature, humidity in
        print("Temperature: \(temperature), Humidity: \(humidity)")
    }

temperaturePublisher.send(72) // No output yet
humidityPublisher.send(45)     // Output: Temperature: 72, Humidity: 45
temperaturePublisher.send(74) // Output: Temperature: 74, Humidity: 45

let usernamePublisher = PassthroughSubject<String, Never>()
let agePublisher = PassthroughSubject<Int, Never>()

let userPublisher = Publishers.Zip(usernamePublisher, agePublisher)
    .sink { username, age in
        print("Username: \(username), Age: \(age)")
    }

usernamePublisher.send("johndoe") // No output yet
agePublisher.send(30)             // Output: Username: johndoe, Age: 30
usernamePublisher.send("janedoe") // No output yet
agePublisher.send(28)             // Output: Username: janedoe, Age: 28
//*/

PlaygroundPage.current.needsIndefiniteExecution = true
